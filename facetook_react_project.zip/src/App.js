import React from "react";
import Facetook from "./FacetookApp";

function App() {
  return <Facetook />;
}

export default App;
